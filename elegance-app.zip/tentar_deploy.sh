#!/bin/bash

echo "🚀 Tentando diferentes métodos para fazer deploy..."
echo ""

# Método 1: HTTPS
echo "📡 Tentativa 1: HTTPS..."
git remote set-url origin https://github.com/Georastreador/elegance-app.git
if git push -u origin main 2>/dev/null; then
    echo "✅ Sucesso com HTTPS!"
    exit 0
fi

# Método 2: SSH
echo "📡 Tentativa 2: SSH..."
git remote set-url origin git@github.com:Georastreador/elegance-app.git
if git push -u origin main 2>/dev/null; then
    echo "✅ Sucesso com SSH!"
    exit 0
fi

# Método 3: HTTPS com configurações especiais
echo "📡 Tentativa 3: HTTPS com configurações especiais..."
git config --global http.version HTTP/1.1
git config --global http.postBuffer 524288000
git remote set-url origin https://github.com/Georastreador/elegance-app.git
if git push -u origin main 2>/dev/null; then
    echo "✅ Sucesso com HTTPS configurado!"
    exit 0
fi

echo ""
echo "❌ Todos os métodos falharam. Problema de conectividade detectado."
echo ""
echo "🛠️ SOLUÇÕES ALTERNATIVAS:"
echo ""
echo "1. 📱 UPLOAD MANUAL (Mais Fácil):"
echo "   - Acesse: https://github.com/Georastreador"
echo "   - Clique em 'New repository'"
echo "   - Nome: elegance-app"
echo "   - Marque como Público"
echo "   - NÃO adicione README, .gitignore ou LICENSE"
echo "   - Clique em 'Create repository'"
echo "   - Clique em 'uploading an existing file'"
echo "   - Arraste todos os arquivos do projeto"
echo "   - Commit: 'Initial commit: Elegance APP'"
echo ""
echo "2. 🌐 VERIFICAR CONECTIVIDADE:"
echo "   - Teste sua conexão com a internet"
echo "   - Tente usar uma rede diferente"
echo "   - Verifique se há firewall bloqueando"
echo ""
echo "3. 📋 ARQUIVOS PRONTOS PARA UPLOAD:"
echo "   ✅ index.html"
echo "   ✅ script.js"
echo "   ✅ style.css"
echo "   ✅ test_api.html"
echo "   ✅ README.md"
echo "   ✅ LICENSE"
echo "   ✅ .gitignore"
echo "   ✅ requirements.txt"
echo "   ✅ instrucoes.txt"
echo "   ✅ env_example.txt"
echo "   ✅ Observações.txt"
echo ""
echo "4. 🔗 APÓS UPLOAD:"
echo "   - Configure GitHub Pages (Settings > Pages)"
echo "   - URL: https://georastreador.github.io/elegance-app/"
echo ""
echo "📞 Se precisar de ajuda, consulte: SOLUCAO_CONEXAO.md"
