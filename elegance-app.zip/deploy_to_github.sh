#!/bin/bash

echo "🚀 Deploying Elegance APP to GitHub..."
echo ""

# Verificar se estamos no diretório correto
if [ ! -f "index.html" ]; then
    echo "❌ Erro: Execute este script no diretório do projeto Elegance APP"
    exit 1
fi

# Verificar status do Git
echo "📋 Verificando status do Git..."
git status

echo ""
echo "🔗 Verificando repositório remoto..."
git remote -v

echo ""
echo "📤 Fazendo push para GitHub..."
echo "Repositório: https://github.com/Georastreador/elegance-app"
echo ""

# Tentar fazer push
if git push -u origin main; then
    echo ""
    echo "✅ Sucesso! Repositório enviado para GitHub!"
    echo ""
    echo "🌐 Links importantes:"
    echo "   Repositório: https://github.com/Georastreador/elegance-app"
    echo "   GitHub Pages: https://georastreador.github.io/elegance-app/"
    echo ""
    echo "📝 Próximos passos:"
    echo "   1. Acesse o repositório no GitHub"
    echo "   2. Configure GitHub Pages (Settings > Pages)"
    echo "   3. Compartilhe o link com usuários"
    echo "   4. Cada usuário insere sua própria chave da API"
else
    echo ""
    echo "❌ Erro no push. Possíveis soluções:"
    echo "   1. Verifique sua conexão com a internet"
    echo "   2. Verifique se o repositório existe no GitHub"
    echo "   3. Verifique suas credenciais do GitHub"
    echo ""
    echo "🔧 Para criar o repositório manualmente:"
    echo "   1. Acesse: https://github.com/Georastreador"
    echo "   2. Clique em 'New repository'"
    echo "   3. Nome: elegance-app"
    echo "   4. Marque como Público"
    echo "   5. NÃO adicione README, .gitignore ou LICENSE"
    echo "   6. Clique em 'Create repository'"
    echo "   7. Execute este script novamente"
fi
